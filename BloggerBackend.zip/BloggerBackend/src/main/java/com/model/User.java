package com.model;

public class User {

}
