package com.dao;

import java.util.List;

import com.model.BlogPost;

public interface BlogPostDao {

	List<BlogPost> getBlogPosts();

	BlogPost getBlogPost(int id);

}
