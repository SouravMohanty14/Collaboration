package com.dao;

import java.util.List;

import com.model.BlogPost;

public class BlogPostDaoImpl implements BlogPostDao
{
	
	@Override
	public List<BlogPost> getBlogPosts() {
	Session session=sessionFactory.openSession();
	Query query=session.createQuery("from BlogPost");
	List<BlogPost> blogPosts=query.list();
	session.close();
	return blogPosts;
	}	

	@Override
	public BlogPost getBlogPost(int id) {
	Session session=sessionFactory.openSession();
	BlogPost blogPost=(BlogPost)session.get(BlogPost.class, id);
	session.close();
	return blogPost;
	}

}
